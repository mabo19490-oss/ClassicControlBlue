Classic Control Blue - مشروع أندرويد أولي

هذا أرشيف مشروع Android Studio لتغليف واجهة الويب داخل تطبيق أندرويد مستقل.
معرّف التطبيق: com.abomohammad.classiccontrolblue
الاسم الظاهر: Classic Control Blue

طريقة بناء APK:
1) افتح Android Studio على كمبيوتر.
2) اختر Open وافتح مجلد ClassicControlBlue بعد فك الضغط.
3) انتظر مزامنة Gradle وتنزيل مكونات Android SDK المطلوبة.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ملف APK التجريبي يظهر عادة في app/build/outputs/apk/debug/app-debug.apk.

ملاحظات:
- هذا مشروع مصدر وليس ملف APK جاهزاً.
- لم يتم بناء APK أو اختباره في هذه البيئة لعدم توفر Android SDK/Gradle.
- التطبيق مستقل عن التطبيق الأصلي بسبب استخدام applicationId مختلف.
- المحاكاة والواجهة هي النسخة التجريبية الموجودة في assets/index.html.
